# Documentation
This folder should include the following files:
- Report.pdf
- DomainModel.pdf
- StaticDesignModel.pdf
- DynamicDesignModel.pdf

Refer the project specification for more details
